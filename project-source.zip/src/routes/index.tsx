import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { analyzeVideo, type AnalysisResult } from "@/lib/analyze-video.functions";
import { parseYouTubeUrl } from "@/lib/youtube-url";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AnalysisView } from "@/components/AnalysisView";
import {
  Brain,
  Sparkles,
  Youtube,
  Zap,
  ArrowRight,
  Loader2,
  GraduationCap,
  Clock,
  ListChecks,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VideoMind AI — Turn videos into notes, quizzes & flashcards" },
      {
        name: "description",
        content:
          "Paste a YouTube URL and get instant AI-generated summaries, timestamps, quizzes, flashcards, and memory tricks. Learn 80% faster.",
      },
      { property: "og:title", content: "VideoMind AI" },
      {
        property: "og:description",
        content: "Turn any video into structured notes, quizzes & flashcards with AI.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: (videoUrl: string) => analyzeVideo({ data: { url: videoUrl } }),
    onSuccess: (data) => setResult(data),
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = url.trim();
    const parsed = parseYouTubeUrl(trimmed);
    if (!parsed.ok) {
      setValidationError(parsed.reason);
      setResult(null);
      mutation.reset();
      return;
    }
    setValidationError(null);
    setResult(null);
    mutation.mutate(trimmed);
  };

  return (
    <main className="min-h-screen">
      <header className="px-6 py-5 flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-[image:var(--gradient-cyber)] grid place-items-center glow-violet">
            <Brain className="w-5 h-5 text-white" />
          </div>
          <span className="font-display font-bold text-lg">
            VideoMind <span className="text-gradient">AI</span>
          </span>
        </div>
        <a
          href="#analyze"
          className="text-sm text-muted-foreground hover:text-foreground transition"
        >
          How it works
        </a>
      </header>

      <section className="px-6 pt-10 pb-16 max-w-5xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs mb-6">
          <Sparkles className="w-3.5 h-3.5 text-[var(--cyan)]" />
          <span>Powered by Lovable AI · Gemini 3</span>
        </div>
        <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold leading-[1.05]">
          Turn any video into
          <br />
          <span className="text-gradient">notes you'll remember.</span>
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          Paste a YouTube link. Get summaries, clickable timestamps, quizzes,
          flashcards & memory tricks in seconds. Learn 80% faster.
        </p>

        <form
          id="analyze"
          onSubmit={onSubmit}
          className="mt-10 glass-strong rounded-2xl p-2 max-w-2xl mx-auto flex gap-2"
        >
          <div className="flex items-center pl-3 text-muted-foreground">
            <Youtube className="w-5 h-5" />
          </div>
          <Input
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              if (validationError) setValidationError(null);
            }}
            placeholder="Paste a YouTube URL…"
            inputMode="url"
            autoComplete="off"
            spellCheck={false}
            maxLength={2048}
            aria-invalid={validationError ? true : undefined}
            className="flex-1 bg-transparent border-0 focus-visible:ring-0 text-base h-12"
          />
          <Button
            type="submit"
            disabled={mutation.isPending || !url.trim()}
            className="h-12 px-6 bg-[image:var(--gradient-violet)] hover:opacity-90 glow-violet"
          >
            {mutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                Analyzing…
              </>
            ) : (
              <>
                Analyze <ArrowRight className="w-4 h-4 ml-1" />
              </>
            )}
          </Button>
        </form>

        {mutation.isPending && (
          <div className="mt-6 text-sm text-muted-foreground animate-pulse">
            Fetching transcript · Identifying topics · Generating notes…
          </div>
        )}

        {validationError && (
          <div
            role="alert"
            className="mt-6 glass rounded-xl p-4 max-w-2xl mx-auto text-sm text-amber-200"
          >
            {validationError}
          </div>
        )}

        {mutation.isError && !validationError && (
          <div className="mt-6 glass rounded-xl p-4 max-w-2xl mx-auto text-sm text-red-300">
            {(mutation.error as Error).message}
          </div>
        )}

        {!result && !mutation.isPending && (
          <div className="mt-16 grid sm:grid-cols-3 gap-4 max-w-4xl mx-auto text-left">
            <Feature
              icon={<Clock className="w-5 h-5" />}
              title="Smart Timestamps"
              body="Auto-chaptered moments you can click to jump to."
            />
            <Feature
              icon={<GraduationCap className="w-5 h-5" />}
              title="Quizzes & Cards"
              body="Active recall material generated from real content."
            />
            <Feature
              icon={<Zap className="w-5 h-5" />}
              title="Remember Forever"
              body="Mnemonics & analogies so concepts truly stick."
            />
          </div>
        )}
      </section>

      {result && (
        <section className="px-6 pb-20 max-w-7xl mx-auto">
          <AnalysisView result={result} />
        </section>
      )}

      <footer className="px-6 py-8 text-center text-xs text-muted-foreground border-t border-white/5">
        Built with VideoMind AI · Transcripts via YouTube · AI by Lovable
      </footer>
    </main>
  );
}

function Feature({
  icon,
  title,
  body,
}: {
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div className="glass rounded-xl p-5">
      <div className="w-10 h-10 rounded-lg bg-white/5 grid place-items-center text-[var(--cyan)] mb-3">
        {icon}
      </div>
      <div className="font-semibold mb-1">{title}</div>
      <div className="text-sm text-muted-foreground">{body}</div>
    </div>
  );
}
