import { forwardRef, useImperativeHandle, useRef } from "react";

export type VideoPlayerHandle = {
  seekTo: (seconds: number) => void;
};

export const VideoPlayer = forwardRef<VideoPlayerHandle, { videoId: string }>(
  function VideoPlayer({ videoId }, ref) {
    const iframeRef = useRef<HTMLIFrameElement>(null);

    useImperativeHandle(ref, () => ({
      seekTo(seconds: number) {
        const iframe = iframeRef.current;
        if (!iframe?.contentWindow) return;
        iframe.contentWindow.postMessage(
          JSON.stringify({
            event: "command",
            func: "seekTo",
            args: [seconds, true],
          }),
          "*",
        );
        iframe.contentWindow.postMessage(
          JSON.stringify({ event: "command", func: "playVideo", args: [] }),
          "*",
        );
      },
    }));

    return (
      <div className="glass-strong overflow-hidden rounded-2xl aspect-video">
        <iframe
          ref={iframeRef}
          className="w-full h-full"
          src={`https://www.youtube.com/embed/${videoId}?enablejsapi=1&rel=0`}
          title="YouTube player"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    );
  },
);
