import { useRef, useState } from "react";
import type { AnalysisResult } from "@/lib/analyze-video.functions";
import { VideoPlayer, type VideoPlayerHandle } from "./VideoPlayer";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Sparkles,
  ListChecks,
  Clock,
  Brain,
  GraduationCap,
  Layers,
  CheckCircle2,
  RotateCcw,
  BookOpen,
} from "lucide-react";
import { Button } from "@/components/ui/button";

function fmtTime(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
    : `${m}:${String(sec).padStart(2, "0")}`;
}

export function AnalysisView({ result }: { result: AnalysisResult }) {
  const playerRef = useRef<VideoPlayerHandle>(null);
  const seek = (t: number) => playerRef.current?.seekTo(t);

  return (
    <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
      <div className="space-y-4 lg:sticky lg:top-6 self-start">
        <VideoPlayer ref={playerRef} videoId={result.videoId} />
        {result.title && (
          <h2 className="text-xl font-semibold">{result.title}</h2>
        )}
        <div className="glass rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2 text-sm text-muted-foreground">
            <Sparkles className="w-4 h-4 text-[var(--violet)]" />
            Executive Summary
          </div>
          <p className="leading-relaxed text-foreground/90">{result.summary}</p>
        </div>
      </div>

      <Tabs defaultValue="chapters" className="w-full">
        <TabsList className="glass w-full flex flex-wrap h-auto p-1">
          <TabsTrigger value="chapters"><Clock className="w-4 h-4 mr-1" />Timestamps</TabsTrigger>
          <TabsTrigger value="notes"><BookOpen className="w-4 h-4 mr-1" />Notes</TabsTrigger>
          <TabsTrigger value="concepts"><Layers className="w-4 h-4 mr-1" />Concepts</TabsTrigger>
          <TabsTrigger value="remember"><Brain className="w-4 h-4 mr-1" />Remember</TabsTrigger>
          <TabsTrigger value="quiz"><GraduationCap className="w-4 h-4 mr-1" />Quiz</TabsTrigger>
          <TabsTrigger value="flashcards"><RotateCcw className="w-4 h-4 mr-1" />Cards</TabsTrigger>
          <TabsTrigger value="actions"><ListChecks className="w-4 h-4 mr-1" />Actions</TabsTrigger>
        </TabsList>

        <TabsContent value="chapters" className="mt-4 space-y-2">
          {result.chapters.map((c, i) => (
            <button
              key={i}
              onClick={() => seek(c.time)}
              className="glass hover:glass-strong w-full text-left rounded-xl p-4 transition-all hover:translate-x-1 hover:shadow-[var(--shadow-glow)]"
            >
              <div className="flex items-baseline gap-3">
                <span className="font-mono text-sm text-[var(--cyan)] tabular-nums">
                  {fmtTime(c.time)}
                </span>
                <span className="font-semibold">{c.title}</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">{c.summary}</p>
            </button>
          ))}
        </TabsContent>

        <TabsContent value="notes" className="mt-4 space-y-3">
          {result.notes.map((n, i) => (
            <div key={i} className="glass rounded-xl p-4">
              <h3 className="font-semibold mb-2 text-gradient">{n.heading}</h3>
              <ul className="space-y-1.5 text-sm">
                {n.points.map((p, j) => (
                  <li key={j} className="flex gap-2">
                    <span className="text-[var(--violet)] mt-0.5">▸</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="concepts" className="mt-4 space-y-2">
          {result.keyConcepts.map((k, i) => (
            <div key={i} className="glass rounded-xl p-4">
              <div className="font-semibold">{k.term}</div>
              <div className="text-sm text-muted-foreground mt-1">{k.definition}</div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="remember" className="mt-4 space-y-2">
          <p className="text-sm text-muted-foreground px-1">
            🧠 Mental shortcuts to lock these concepts into long-term memory.
          </p>
          {result.rememberForever.map((r, i) => (
            <div key={i} className="glass rounded-xl p-4 border-l-2 border-[var(--violet)]">
              <div className="font-semibold">{r.concept}</div>
              <div className="text-sm text-foreground/80 mt-1">💡 {r.trick}</div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="quiz" className="mt-4 space-y-3">
          {result.quiz.map((q, i) => (
            <QuizItem key={i} index={i} q={q} />
          ))}
        </TabsContent>

        <TabsContent value="flashcards" className="mt-4">
          <div className="grid sm:grid-cols-2 gap-3">
            {result.flashcards.map((f, i) => (
              <Flashcard key={i} front={f.front} back={f.back} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="actions" className="mt-4 space-y-2">
          {result.actionItems.map((a, i) => (
            <div key={i} className="glass rounded-xl p-3 flex gap-3 items-start">
              <CheckCircle2 className="w-5 h-5 text-[var(--cyan)] shrink-0 mt-0.5" />
              <span className="text-sm">{a}</span>
            </div>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function QuizItem({
  index,
  q,
}: {
  index: number;
  q: AnalysisResult["quiz"][number];
}) {
  const [picked, setPicked] = useState<number | null>(null);
  return (
    <div className="glass rounded-xl p-4">
      <div className="font-medium mb-3">
        <span className="text-[var(--violet)] mr-2">Q{index + 1}.</span>
        {q.question}
      </div>
      <div className="space-y-2">
        {q.options.map((opt, i) => {
          const isCorrect = i === q.answerIndex;
          const isPicked = picked === i;
          const show = picked !== null;
          return (
            <button
              key={i}
              disabled={show}
              onClick={() => setPicked(i)}
              className={`w-full text-left text-sm rounded-lg px-3 py-2 border transition ${
                show && isCorrect
                  ? "bg-emerald-500/15 border-emerald-500/40"
                  : show && isPicked
                    ? "bg-red-500/15 border-red-500/40"
                    : "border-white/10 hover:border-[var(--violet)]/60 hover:bg-white/5"
              }`}
            >
              {String.fromCharCode(65 + i)}. {opt}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <div className="mt-3 text-sm text-muted-foreground border-t border-white/10 pt-3">
          {picked === q.answerIndex ? "✅ Correct! " : "❌ Not quite. "}
          {q.explanation}
        </div>
      )}
    </div>
  );
}

function Flashcard({ front, back }: { front: string; back: string }) {
  const [flipped, setFlipped] = useState(false);
  return (
    <button
      onClick={() => setFlipped((f) => !f)}
      className="glass hover:glass-strong rounded-xl p-4 min-h-[140px] text-left transition hover:shadow-[var(--shadow-glow)]"
    >
      <div className="text-xs uppercase tracking-wide text-muted-foreground mb-2">
        {flipped ? "Answer" : "Question"}
      </div>
      <div className={flipped ? "text-sm" : "font-medium"}>
        {flipped ? back : front}
      </div>
      <div className="text-xs text-[var(--violet)] mt-3">Tap to flip</div>
    </button>
  );
}
