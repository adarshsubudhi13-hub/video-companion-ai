// Strict YouTube URL validation shared by client and server.

const ID_RE = /^[A-Za-z0-9_-]{11}$/;

const ALLOWED_HOSTS = new Set([
  "youtube.com",
  "www.youtube.com",
  "m.youtube.com",
  "music.youtube.com",
  "youtu.be",
  "www.youtu.be",
]);

export type YouTubeParseResult =
  | { ok: true; videoId: string }
  | { ok: false; reason: string };

export function parseYouTubeUrl(raw: string): YouTubeParseResult {
  const input = (raw ?? "").trim();
  if (!input) return { ok: false, reason: "Please paste a YouTube URL." };

  // Bare 11-char video id.
  if (ID_RE.test(input)) return { ok: true, videoId: input };

  // Require a parseable http(s) URL.
  let u: URL;
  try {
    u = new URL(input.includes("://") ? input : `https://${input}`);
  } catch {
    return { ok: false, reason: "That doesn't look like a valid URL." };
  }

  if (u.protocol !== "http:" && u.protocol !== "https:") {
    return { ok: false, reason: "URL must start with http:// or https://." };
  }

  const host = u.hostname.toLowerCase();
  if (!ALLOWED_HOSTS.has(host)) {
    return {
      ok: false,
      reason:
        "Only YouTube links are supported (youtube.com, youtu.be, m.youtube.com, music.youtube.com).",
    };
  }

  // youtu.be/<id>
  if (host === "youtu.be" || host === "www.youtu.be") {
    const id = u.pathname.split("/").filter(Boolean)[0] ?? "";
    if (ID_RE.test(id)) return { ok: true, videoId: id };
    return { ok: false, reason: "Couldn't find a video ID in that youtu.be link." };
  }

  // youtube.com/watch?v=<id>
  if (u.pathname === "/watch") {
    const id = u.searchParams.get("v") ?? "";
    if (ID_RE.test(id)) return { ok: true, videoId: id };
    return { ok: false, reason: "Missing or invalid ?v= video ID in the YouTube URL." };
  }

  // youtube.com/shorts/<id>, /embed/<id>, /live/<id>, /v/<id>
  const segs = u.pathname.split("/").filter(Boolean);
  if (segs.length >= 2 && ["shorts", "embed", "live", "v"].includes(segs[0])) {
    if (ID_RE.test(segs[1])) return { ok: true, videoId: segs[1] };
    return { ok: false, reason: "Invalid video ID in the YouTube URL." };
  }

  return {
    ok: false,
    reason:
      "Unsupported YouTube URL. Try a standard watch link, youtu.be link, or Shorts URL.",
  };
}
