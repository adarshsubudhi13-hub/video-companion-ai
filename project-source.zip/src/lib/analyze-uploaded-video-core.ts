import { z } from "zod";

export type UploadedVideoAnalysis = {
  objectKey: string;
  summary: string;
  keyConcepts: { term: string; definition: string }[];
  notes: { heading: string; points: string[] }[];
  actionItems: string[];
  quiz: {
    question: string;
    options: string[];
    answerIndex: number;
    explanation: string;
  }[];
  flashcards: { front: string; back: string }[];
};

const str = (fallback = "") =>
  z.preprocess(
    (v) => (v == null ? fallback : typeof v === "string" ? v : String(v)),
    z.string(),
  );
const num = (fallback = 0) =>
  z.preprocess((v) => {
    if (typeof v === "number") return v;
    if (typeof v === "string") {
      const n = parseFloat(v);
      return isNaN(n) ? fallback : n;
    }
    return fallback;
  }, z.number());

const OutputSchema = z.object({
  summary: str("Summary unavailable."),
  keyConcepts: z
    .array(z.object({ term: str(), definition: str() }))
    .default([]),
  notes: z
    .array(z.object({ heading: str(), points: z.array(str()) }))
    .default([]),
  actionItems: z.array(str()).default([]),
  quiz: z
    .array(
      z.object({
        question: str(),
        options: z.array(str()),
        answerIndex: num(),
        explanation: str(),
      }),
    )
    .default([]),
  flashcards: z
    .array(z.object({ front: str(), back: str() }))
    .default([]),
});

// Guess a video MIME type from the object key extension.
function guessMime(key: string): string {
  const ext = key.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    mp4: "video/mp4",
    mov: "video/quicktime",
    webm: "video/webm",
    mkv: "video/x-matroska",
    avi: "video/x-msvideo",
    m4v: "video/mp4",
  };
  return map[ext] ?? "video/mp4";
}

// Base64-encode a Uint8Array without blowing the call stack on large inputs.
function toBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(
      ...bytes.subarray(i, Math.min(i + chunk, bytes.length)),
    );
  }
  // btoa is available in the Cloudflare Worker runtime.
  return btoa(binary);
}

export async function analyzeUploadedVideo(
  objectKey: string,
): Promise<UploadedVideoAnalysis> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");

  if (!objectKey || typeof objectKey !== "string") {
    throw new Error("object_key is required.");
  }

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: blob, error } = await supabaseAdmin.storage
    .from("video-uploads")
    .download(objectKey);
  if (error || !blob) {
    throw new Error(
      `Couldn't find the uploaded video at "${objectKey}". Upload it first with create_video_upload_url.`,
    );
  }

  const MAX_BYTES = 20 * 1024 * 1024; // 20 MB safe ceiling for Worker memory
  const buf = new Uint8Array(await blob.arrayBuffer());
  if (buf.byteLength > MAX_BYTES) {
    throw new Error(
      `Video is ${(buf.byteLength / 1024 / 1024).toFixed(1)} MB — please upload a clip under 20 MB.`,
    );
  }

  const mime = guessMime(objectKey);
  const dataUrl = `data:${mime};base64,${toBase64(buf)}`;

  const system = `You are VideoMind AI. You will receive an uploaded video. Watch it and produce structured learning material based ONLY on what appears in the video.

Return ONLY valid JSON matching this exact shape (no markdown, no prose):
{
  "summary": "1-2 paragraph executive summary",
  "keyConcepts": [{ "term": "string", "definition": "string" }],
  "notes": [{ "heading": "string", "points": ["string"] }],
  "actionItems": ["string"],
  "quiz": [{ "question": "string", "options": ["a","b","c","d"], "answerIndex": 0, "explanation": "string" }],
  "flashcards": [{ "front": "string", "back": "string" }]
}

Requirements:
- Generate AT LEAST 15 quiz questions (each with 4 options and a correct answerIndex 0-3).
- Generate AT LEAST 10 flashcards, 6 notes sections (4-8 points each), 8 keyConcepts, 5 actionItems.
- Use clear beginner-friendly language. Do NOT invent facts not in the video.`;

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: system },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this uploaded video and return the JSON learning material.",
            },
            {
              type: "file",
              file: { filename: objectKey.split("/").pop() ?? "video", file_data: dataUrl },
            },
          ],
        },
      ],
      response_format: { type: "json_object" },
    }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    console.error("Lovable AI Gateway error", res.status, text);
    if (res.status === 429) throw new Error("Rate limit reached. Please try again in a moment.");
    if (res.status === 402) throw new Error("AI credits exhausted. Add credits to continue.");
    throw new Error("AI processing failed. Please try again later.");
  }

  const j = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const content = j.choices?.[0]?.message?.content;
  if (!content) throw new Error("AI returned an empty response.");

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new Error("AI returned malformed JSON.");
  }
  const out = OutputSchema.parse(parsed);
  return { objectKey, ...out };
}

export async function createVideoUploadUrl(filename: string) {
  if (!filename || typeof filename !== "string") {
    throw new Error("filename is required.");
  }
  const safe = filename.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80) || "video.mp4";
  const objectKey = `${crypto.randomUUID()}-${safe}`;

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.storage
    .from("video-uploads")
    .createSignedUploadUrl(objectKey);
  if (error || !data) {
    throw new Error(`Could not create upload URL: ${error?.message ?? "unknown error"}`);
  }
  return {
    object_key: objectKey,
    upload_url: data.signedUrl,
    method: "PUT" as const,
    expires_in_seconds: 60 * 60,
    instructions:
      "PUT the raw video bytes to upload_url with the Content-Type header set to the video's MIME type (e.g. video/mp4). Then call analyze_uploaded_video with object_key.",
  };
}
