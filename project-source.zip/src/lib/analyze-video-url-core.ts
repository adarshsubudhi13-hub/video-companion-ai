import { z } from "zod";

export type VideoUrlAnalysis = {
  sourceUrl: string;
  summary: string;
  keyConcepts: { term: string; definition: string }[];
  notes: { heading: string; points: string[] }[];
  actionItems: string[];
  quiz: {
    question: string;
    options: string[];
    answerIndex: number;
    explanation: string;
  }[];
  flashcards: { front: string; back: string }[];
};

const str = (fallback = "") =>
  z.preprocess(
    (v) => (v == null ? fallback : typeof v === "string" ? v : String(v)),
    z.string(),
  );
const num = (fallback = 0) =>
  z.preprocess((v) => {
    if (typeof v === "number") return v;
    if (typeof v === "string") {
      const n = parseFloat(v);
      return isNaN(n) ? fallback : n;
    }
    return fallback;
  }, z.number());

const OutputSchema = z.object({
  summary: str("Summary unavailable."),
  keyConcepts: z
    .array(z.object({ term: str(), definition: str() }))
    .default([]),
  notes: z
    .array(z.object({ heading: str(), points: z.array(str()) }))
    .default([]),
  actionItems: z.array(str()).default([]),
  quiz: z
    .array(
      z.object({
        question: str(),
        options: z.array(str()),
        answerIndex: num(),
        explanation: str(),
      }),
    )
    .default([]),
  flashcards: z
    .array(z.object({ front: str(), back: str() }))
    .default([]),
});

const EXT_MIME: Record<string, string> = {
  mp4: "video/mp4",
  m4v: "video/mp4",
  mov: "video/quicktime",
  webm: "video/webm",
  mkv: "video/x-matroska",
  avi: "video/x-msvideo",
};

function mimeFromUrl(url: string, headerMime?: string | null): string {
  if (headerMime && headerMime.startsWith("video/")) return headerMime.split(";")[0].trim();
  const path = (() => {
    try {
      return new URL(url).pathname;
    } catch {
      return url;
    }
  })();
  const ext = path.split(".").pop()?.toLowerCase() ?? "";
  return EXT_MIME[ext] ?? "video/mp4";
}

function toBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(
      ...bytes.subarray(i, Math.min(i + chunk, bytes.length)),
    );
  }
  return btoa(binary);
}

function isYouTube(u: URL): boolean {
  const h = u.hostname.toLowerCase().replace(/^www\./, "");
  return (
    h === "youtube.com" ||
    h.endsWith(".youtube.com") ||
    h === "youtu.be" ||
    h === "youtube-nocookie.com"
  );
}

export async function analyzeVideoUrl(sourceUrl: string): Promise<VideoUrlAnalysis> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) throw new Error("Missing LOVABLE_API_KEY");

  if (!sourceUrl || typeof sourceUrl !== "string") {
    throw new Error("url is required.");
  }

  let parsed: URL;
  try {
    parsed = new URL(sourceUrl);
  } catch {
    throw new Error("Invalid URL. Provide a full https:// URL to a video file.");
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw new Error("URL must use http or https.");
  }
  if (isYouTube(parsed)) {
    throw new Error(
      "This tool is for direct video file URLs. Use analyze_youtube_video for YouTube links.",
    );
  }

  const MAX_BYTES = 20 * 1024 * 1024;
  const res = await fetch(sourceUrl, { redirect: "follow" });
  if (!res.ok || !res.body) {
    throw new Error(`Couldn't download the video (HTTP ${res.status}).`);
  }
  const declaredLen = Number(res.headers.get("content-length") ?? "0");
  if (declaredLen && declaredLen > MAX_BYTES) {
    throw new Error(
      `Video is ${(declaredLen / 1024 / 1024).toFixed(1)} MB — please provide a URL to a clip under 20 MB.`,
    );
  }

  const buf = new Uint8Array(await res.arrayBuffer());
  if (buf.byteLength > MAX_BYTES) {
    throw new Error(
      `Video is ${(buf.byteLength / 1024 / 1024).toFixed(1)} MB — please provide a URL to a clip under 20 MB.`,
    );
  }

  const mime = mimeFromUrl(sourceUrl, res.headers.get("content-type"));
  const filename = parsed.pathname.split("/").pop() || "video.mp4";
  const dataUrl = `data:${mime};base64,${toBase64(buf)}`;

  const system = `You are VideoMind AI. You will receive a video downloaded from a public URL. Watch the ENTIRE video and produce structured learning material based ONLY on what appears in the video.

Return ONLY valid JSON matching this exact shape (no markdown, no prose):
{
  "summary": "1-2 paragraph executive summary of the full video",
  "keyConcepts": [{ "term": "string", "definition": "string" }],
  "notes": [{ "heading": "string", "points": ["string"] }],
  "actionItems": ["string"],
  "quiz": [{ "question": "string", "options": ["a","b","c","d"], "answerIndex": 0, "explanation": "string" }],
  "flashcards": [{ "front": "string", "back": "string" }]
}

Requirements:
- Cover the WHOLE video, not just the first minute.
- Generate AT LEAST 15 quiz questions (each with 4 options and a correct answerIndex 0-3).
- Generate AT LEAST 10 flashcards, 6 notes sections (4-8 points each), 8 keyConcepts, 5 actionItems.
- Use clear beginner-friendly language. Do NOT invent facts not in the video.`;

  const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: system },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analyze this video (${filename}) from ${sourceUrl} and return the JSON learning material for the whole video.`,
            },
            {
              type: "file",
              file: { filename, file_data: dataUrl },
            },
          ],
        },
      ],
      response_format: { type: "json_object" },
    }),
  });

  if (!aiRes.ok) {
    const text = await aiRes.text().catch(() => "");
    console.error("Lovable AI Gateway error", aiRes.status, text);
    if (aiRes.status === 429) throw new Error("Rate limit reached. Please try again in a moment.");
    if (aiRes.status === 402) throw new Error("AI credits exhausted. Add credits to continue.");
    throw new Error("AI processing failed. Please try again later.");
  }

  const j = (await aiRes.json()) as { choices?: { message?: { content?: string } }[] };
  const content = j.choices?.[0]?.message?.content;
  if (!content) throw new Error("AI returned an empty response.");

  let parsedJson: unknown;
  try {
    parsedJson = JSON.parse(content);
  } catch {
    throw new Error("AI returned malformed JSON.");
  }
  const out = OutputSchema.parse(parsedJson);
  return { sourceUrl, ...out };
}
