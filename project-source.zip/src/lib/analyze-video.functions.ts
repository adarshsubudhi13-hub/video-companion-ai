import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/start-server-core";
import { z } from "zod";
import { YoutubeTranscript } from "youtube-transcript";
import { parseYouTubeUrl } from "./youtube-url";

const InputSchema = z.object({ url: z.string().trim().min(1).max(2048) });

export type AnalysisResult = {
  videoId: string;
  title?: string;
  summary: string;
  keyConcepts: { term: string; definition: string }[];
  chapters: { time: number; title: string; summary: string }[];
  notes: { heading: string; points: string[] }[];
  rememberForever: { concept: string; trick: string }[];
  actionItems: string[];
  quiz: {
    question: string;
    options: string[];
    answerIndex: number;
    explanation: string;
  }[];
  flashcards: { front: string; back: string }[];
};

const str = (fallback = "") =>
  z.preprocess((v) => (v == null ? fallback : typeof v === "string" ? v : String(v)), z.string());
const num = (fallback = 0) =>
  z.preprocess((v) => {
    if (typeof v === "number") return v;
    if (typeof v === "string") {
      const n = parseFloat(v);
      return isNaN(n) ? fallback : n;
    }
    return fallback;
  }, z.number());

const KeyConcept = z.preprocess(
  (v) => (typeof v === "string" ? { term: v, definition: "" } : v),
  z.object({ term: str(), definition: str() }),
);
const Chapter = z.object({ time: num(), title: str(), summary: str() });
const Note = z.preprocess(
  (v: any) => {
    if (typeof v === "string") return { heading: v, points: [] };
    if (v && !Array.isArray(v.points)) return { ...v, points: v.points ? [String(v.points)] : [] };
    return v;
  },
  z.object({ heading: str(), points: z.array(str()) }),
);
const Remember = z.preprocess(
  (v) => (typeof v === "string" ? { concept: v, trick: "" } : v),
  z.object({ concept: str(), trick: str() }),
);
const Quiz = z.object({
  question: str(),
  options: z.array(str()),
  answerIndex: num(),
  explanation: str(),
});
const Flashcard = z.preprocess(
  (v) => (typeof v === "string" ? { front: v, back: "" } : v),
  z.object({ front: str(), back: str() }),
);

const OutputSchema = z.object({
  summary: str("Summary unavailable."),
  keyConcepts: z.array(KeyConcept).default([]),
  chapters: z.array(Chapter).default([]),
  notes: z.array(Note).default([]),
  rememberForever: z.array(Remember).default([]),
  actionItems: z.array(str()).default([]),
  quiz: z.array(Quiz).default([]),
  flashcards: z.array(Flashcard).default([]),
});

export const analyzeVideo = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => InputSchema.parse(d))
  .handler(async ({ data }): Promise<AnalysisResult> => {
    // Same-origin guard: raises the bar against cross-origin abuse of this
    // paid endpoint. Not a substitute for auth, but prevents trivial scripted
    // calls from other origins exhausting AI credits.
    try {
      const req = getRequest();
      const host = req.headers.get("host");
      const origin = req.headers.get("origin");
      const referer = req.headers.get("referer");
      const source = origin ?? referer;
      if (!source || !host) {
        throw new Error("Forbidden");
      }
      let sourceHost: string;
      try {
        sourceHost = new URL(source).host;
      } catch {
        throw new Error("Forbidden");
      }
      if (sourceHost !== host) {
        throw new Error("Forbidden");
      }
    } catch (e) {
      if (e instanceof Error && e.message === "Forbidden") throw e;
      throw new Error("Forbidden");
    }

    const key = process.env.LOVABLE_API_KEY;

    const yt = parseYouTubeUrl(data.url);
    if (!yt.ok) {
      throw new Error(yt.reason);
    }
    const videoId = yt.videoId;

    // Fetch transcript
    let transcriptItems: { text: string; offset: number; duration: number }[] = [];
    try {
      const raw = await YoutubeTranscript.fetchTranscript(videoId);
      transcriptItems = raw.map((r) => ({
        text: r.text,
        offset: typeof r.offset === "number" ? r.offset : 0,
        duration: typeof r.duration === "number" ? r.duration : 0,
      }));
    } catch (e) {
      throw new Error(
        "Couldn't fetch the transcript for this video. It may have captions disabled.",
      );
    }
    if (!transcriptItems.length) {
      throw new Error("No transcript available for this video.");
    }

    // Normalize offsets to seconds once.
    const toSec = (offset: number) => Math.floor(offset / (offset > 10000 ? 1000 : 1));
    const items = transcriptItems.map((t) => ({
      sec: toSec(t.offset ?? 0),
      dur: toSec(t.duration ?? 0),
      text: t.text,
    }));
    const lastItem = items[items.length - 1];
    const durationSec = (lastItem?.sec ?? 0) + (lastItem?.dur ?? 0);

    // Try fetch video title
    let title: string | undefined;
    try {
      const r = await fetch(
        `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`,
      );
      if (r.ok) {
        const j = (await r.json()) as { title?: string };
        title = j.title;
      }
    } catch {}

    // ---------- CHUNKED PROCESSING ----------
    // Split transcript into fixed time windows so the ENTIRE video is analyzed
    // regardless of length. Each window is analyzed independently, then merged.
    // (Whisper-style audio transcription isn't available in the Worker runtime,
    // so we chunk the caption transcript by time segments instead — same
    // end-to-end coverage guarantee.)
    const CHUNK_SECONDS = 10 * 60;
    const chunkCount = Math.max(1, Math.ceil(durationSec / CHUNK_SECONDS));
    const chunks: { start: number; end: number; text: string }[] = [];
    for (let i = 0; i < chunkCount; i++) {
      const start = i * CHUNK_SECONDS;
      const end = Math.min(durationSec || (i + 1) * CHUNK_SECONDS, (i + 1) * CHUNK_SECONDS);
      const seg = items.filter((it) => it.sec >= start && (it.sec < end || i === chunkCount - 1));
      if (!seg.length) continue;
      const text = seg.map((s) => `[${s.sec}s] ${s.text}`).join("\n");
      chunks.push({ start, end, text });
    }
    if (!chunks.length) {
      chunks.push({
        start: 0,
        end: durationSec,
        text: items.map((s) => `[${s.sec}s] ${s.text}`).join("\n"),
      });
    }

    const perChunk = { chapters: 3, concepts: 4, notes: 3, quiz: 5, flashcards: 6, remember: 2, actions: 2 };

    const chunkSystemPrompt = `You are VideoMind AI. You will receive ONE time-segment of a longer video transcript. Produce structured learning material for THIS SEGMENT ONLY, using ONLY facts present in the segment.

Return ONLY valid JSON matching this exact shape (no markdown, no prose):
{
  "summary": "string (1-2 paragraphs summarizing this segment)",
  "keyConcepts": [{ "term": "string", "definition": "string" }],
  "chapters": [{ "time": 0, "title": "string", "summary": "string" }],
  "notes": [{ "heading": "string", "points": ["string"] }],
  "rememberForever": [{ "concept": "string", "trick": "string" }],
  "actionItems": ["string"],
  "quiz": [{ "question": "string", "options": ["a","b","c","d"], "answerIndex": 0, "explanation": "string" }],
  "flashcards": [{ "front": "string", "back": "string" }]
}

Rules:
- Every array item MUST be an object with the exact keys above (never a bare string).
- "time" values are SECONDS (integers) using the real timestamps shown in the transcript.
- Generate roughly: ${perChunk.chapters} chapters, ${perChunk.concepts} keyConcepts, ${perChunk.notes} notes (each 4-8 points), ${perChunk.remember} rememberForever, ${perChunk.actions} actionItems, ${perChunk.quiz} quiz questions (4 options each, answerIndex 0-3), ${perChunk.flashcards} flashcards.
- Use clear beginner-friendly language. Do NOT invent facts.`;

    const analyzeChunk = async (chunk: { start: number; end: number; text: string }, index: number) => {
      const userPrompt = `Video title: ${title ?? "Unknown"}
Segment ${index + 1} of ${chunks.length} — covers ${chunk.start}s to ${chunk.end}s of a ${durationSec}s video.

Timestamped transcript for THIS segment:
${chunk.text}

Return the JSON learning material for this segment only.`;

      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: chunkSystemPrompt },
            { role: "user", content: userPrompt },
          ],
          response_format: { type: "json_object" },
        }),
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        console.error("Lovable AI Gateway error", res.status, text);
        if (res.status === 429) throw new Error("Rate limit reached. Please try again in a moment.");
        if (res.status === 402) throw new Error("AI credits exhausted. Add credits to continue.");
        throw new Error("AI processing failed. Please try again later.");
      }
      const j = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const content = j.choices?.[0]?.message?.content;
      if (!content) throw new Error("AI returned an empty response.");
      let parsed: unknown;
      try {
        parsed = JSON.parse(content);
      } catch {
        throw new Error("AI returned malformed JSON.");
      }
      return OutputSchema.parse(parsed);
    };

    // Bounded concurrency to stay under rate limits on long videos.
    const CONCURRENCY = 3;
    const results: z.infer<typeof OutputSchema>[] = [];
    for (let i = 0; i < chunks.length; i += CONCURRENCY) {
      const batch = chunks.slice(i, i + CONCURRENCY);
      const settled = await Promise.all(batch.map((c, k) => analyzeChunk(c, i + k)));
      results.push(...settled);
    }

    // ---------- MERGE ----------
    const merged = {
      summary: results
        .map(
          (r, i) =>
            `Part ${i + 1} (${Math.floor(chunks[i].start / 60)}–${Math.ceil(chunks[i].end / 60)} min): ${r.summary}`,
        )
        .join("\n\n"),
      keyConcepts: [] as { term: string; definition: string }[],
      chapters: [] as { time: number; title: string; summary: string }[],
      notes: [] as { heading: string; points: string[] }[],
      rememberForever: [] as { concept: string; trick: string }[],
      actionItems: [] as string[],
      quiz: [] as { question: string; options: string[]; answerIndex: number; explanation: string }[],
      flashcards: [] as { front: string; back: string }[],
    };
    for (const r of results) {
      merged.keyConcepts.push(...r.keyConcepts);
      merged.chapters.push(...r.chapters);
      merged.notes.push(...r.notes);
      merged.rememberForever.push(...r.rememberForever);
      merged.actionItems.push(...r.actionItems);
      merged.quiz.push(...r.quiz);
      merged.flashcards.push(...r.flashcards);
    }
    const seen = new Set<string>();
    merged.keyConcepts = merged.keyConcepts.filter((c) => {
      const k = c.term.toLowerCase().trim();
      if (!k || seen.has("kc:" + k)) return false;
      seen.add("kc:" + k);
      return true;
    });
    merged.actionItems = merged.actionItems.filter((a) => {
      const k = a.toLowerCase().trim();
      if (!k || seen.has("ai:" + k)) return false;
      seen.add("ai:" + k);
      return true;
    });
    merged.chapters.sort((a, b) => a.time - b.time);

    return { videoId, title, ...merged };
  });
