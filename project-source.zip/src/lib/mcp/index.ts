import { defineMcp } from "@lovable.dev/mcp-js";
import analyzeYoutubeVideo from "./tools/analyze-youtube-video";
import createVideoUploadUrl from "./tools/create-video-upload-url";
import analyzeUploadedVideo from "./tools/analyze-uploaded-video";
import analyzeVideoUrl from "./tools/analyze-video-url";

export default defineMcp({
  name: "videomind-mcp",
  title: "VideoMind AI",
  version: "0.3.0",
  instructions:
    "Tools for turning videos into structured learning material. Use `analyze_youtube_video` for a YouTube URL, `analyze_video_url` for any other public direct video file URL (mp4/mov/webm/mkv). For an uploaded file, first call `create_video_upload_url` to get a presigned PUT URL, upload the raw bytes, then call `analyze_uploaded_video` with the returned object_key. All tools return a summary, notes, flashcards, and 15+ quiz questions.",
  tools: [analyzeYoutubeVideo, analyzeVideoUrl, createVideoUploadUrl, analyzeUploadedVideo],
});
