import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { analyzeUploadedVideo } from "@/lib/analyze-uploaded-video-core";

export default defineTool({
  name: "analyze_uploaded_video",
  title: "Analyze uploaded video",
  description:
    "Analyze a previously uploaded video (via create_video_upload_url) and return structured learning material: executive summary, key concepts, study notes, action items, at least 15 quiz questions, and flashcards.",
  inputSchema: {
    object_key: z
      .string()
      .min(1)
      .describe("The object_key returned by create_video_upload_url after the PUT upload completes."),
  },
  annotations: {
    readOnlyHint: true,
    idempotentHint: false,
    openWorldHint: false,
  },
  handler: async ({ object_key }) => {
    try {
      const result = await analyzeUploadedVideo(object_key);
      return {
        content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
        structuredContent: result as unknown as Record<string, unknown>,
      };
    } catch (e) {
      const message = e instanceof Error ? e.message : "Analysis failed.";
      return { content: [{ type: "text", text: message }], isError: true };
    }
  },
});
