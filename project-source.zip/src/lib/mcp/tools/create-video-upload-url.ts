import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { createVideoUploadUrl } from "@/lib/analyze-uploaded-video-core";

export default defineTool({
  name: "create_video_upload_url",
  title: "Create video upload URL",
  description:
    "Create a short-lived presigned PUT URL that the caller can use to upload a video file (mp4, mov, webm, mkv, up to 20 MB). Returns an object_key to pass to analyze_uploaded_video after uploading.",
  inputSchema: {
    filename: z
      .string()
      .min(1)
      .describe("Original filename of the video, e.g. 'lecture.mp4'. Used only to pick an extension."),
  },
  annotations: {
    readOnlyHint: false,
    idempotentHint: false,
    openWorldHint: false,
  },
  handler: async ({ filename }) => {
    try {
      const result = await createVideoUploadUrl(filename);
      return {
        content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
        structuredContent: result as unknown as Record<string, unknown>,
      };
    } catch (e) {
      const message = e instanceof Error ? e.message : "Could not create upload URL.";
      return { content: [{ type: "text", text: message }], isError: true };
    }
  },
});
