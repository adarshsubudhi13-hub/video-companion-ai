import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { analyzeVideoUrl } from "@/lib/analyze-video-url-core";

export default defineTool({
  name: "analyze_video_url",
  title: "Analyze video from URL",
  description:
    "Analyze a publicly accessible video file (non-YouTube) from its direct https URL and return structured learning material for the WHOLE video: summary, key concepts, notes, action items, at least 15 quiz questions, and flashcards. Supports mp4, mov, webm, mkv up to 20 MB. For YouTube links use analyze_youtube_video instead.",
  inputSchema: {
    url: z
      .string()
      .min(1)
      .describe(
        "Direct https URL to a public video file (mp4, mov, webm, mkv). Not a YouTube URL, not a webpage that embeds a video.",
      ),
  },
  annotations: {
    readOnlyHint: true,
    idempotentHint: false,
    openWorldHint: true,
  },
  handler: async ({ url }) => {
    try {
      const result = await analyzeVideoUrl(url);
      return {
        content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
        structuredContent: result as unknown as Record<string, unknown>,
      };
    } catch (e) {
      const message = e instanceof Error ? e.message : "Analysis failed.";
      return { content: [{ type: "text", text: message }], isError: true };
    }
  },
});
