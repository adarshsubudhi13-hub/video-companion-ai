import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { analyzeYouTubeVideo } from "@/lib/analyze-video-core";

export default defineTool({
  name: "analyze_youtube_video",
  title: "Analyze YouTube video",
  description:
    "Analyze a YouTube video from its URL and return structured learning material: summary, key concepts, timestamped chapters, study notes, mnemonic aids, action items, a quiz, and flashcards. Requires the video to have captions available.",
  inputSchema: {
    url: z
      .string()
      .min(1)
      .describe(
        "YouTube video URL (watch, youtu.be, shorts, embed, live) or a bare 11-character video ID.",
      ),
  },
  annotations: {
    readOnlyHint: true,
    idempotentHint: false,
    openWorldHint: true,
  },
  handler: async ({ url }) => {
    try {
      const result = await analyzeYouTubeVideo(url);
      return {
        content: [{ type: "text", text: JSON.stringify(result, null, 2) }],
        structuredContent: result as unknown as Record<string, unknown>,
      };
    } catch (e) {
      const message = e instanceof Error ? e.message : "Analysis failed.";
      return { content: [{ type: "text", text: message }], isError: true };
    }
  },
});
